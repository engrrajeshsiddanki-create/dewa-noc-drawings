SiteLedger UAE: Primavera P6 exchange package
Project: Al Furjan G+4 Residential Building
Data date: 2026-11-23

AFR-G4_P6_2026-11-23.xer  Import in P6 Professional (File > Import > XER). Contains PROJECT, CALENDAR (UAE work week + holidays), PROJWBS (16 lifecycle stages), TASK (baseline as target dates, current early/late dates, float, actuals), TASKPRED (FS/SS/FF + lags) and UDFs (BOQ refs, duration basis).
AFR-G4_P6_2026-11-23.xml  P6 XML (APIBusinessObjects) for P6 EPPM or tools that read XML.
AFR-G4_P6_2026-11-23_activities.csv  Flat activity list for Excel.

After updating in P6, export an .xer and import it in SiteLedger to sync dates, float and critical path.
Check an import in a sandbox P6 database before using it on a live project.
